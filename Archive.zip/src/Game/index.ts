import GameView from './GamePlay';

export {GameView};
