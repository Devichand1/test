import {PRIMARY_COLOR} from '../constants/colors';

const useStyles = () => {
  return {
    container: {
      flex: 1,
      backgroundColor: PRIMARY_COLOR,
    },
  };
};
export default useStyles;
